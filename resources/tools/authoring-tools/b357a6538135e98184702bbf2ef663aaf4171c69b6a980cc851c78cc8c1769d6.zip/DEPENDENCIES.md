# Dependencies and rights


These packages are restored by .NET, not copied into RuneSchema's runtime DLLs:

| Package | Version | Upstream license |
| --- | --- | --- |
| [CUE4Parse](https://github.com/FabianFG/CUE4Parse) | 1.2.2.202609 | Apache-2.0 |
| [AssetRipper.TextureDecoder](https://github.com/AssetRipper/TextureDecoder) | 2.6.2 | MIT |
| [SkiaSharp](https://github.com/mono/SkiaSharp) | 2.88.9 | MIT |
| Microsoft.Bcl.Memory | 10.0.10 | MIT |
| SharpCompress | 1.0.0 | MIT |

Their transitive dependencies retain their own notices/licenses; see the NuGet
package metadata and `packages.lock.json`. The tool reads desktop block/raw
texture formats through AssetRipper; it does not use CUE4Parse-Conversion or
ImageSharp's encoding pipeline.

The builder automatically selects offline mappings and prepares CUE4Parse's
pinned decoder, or accepts explicit local overrides. Downloaded inputs stay in
the authoring-tools AppData cache and never replace runtime mappings.
RSDW Archive game schemas remain Jagex's property; the Oodle decoder retains its
upstream license. Neither is bundled in the authoring ZIP. Do not include game PAKs, mappings, decoder DLLs,
player saves or private diagnostic files when distributing the cache tool.
Generated artwork/text retains its original rights; a cache is not a rights grant.
