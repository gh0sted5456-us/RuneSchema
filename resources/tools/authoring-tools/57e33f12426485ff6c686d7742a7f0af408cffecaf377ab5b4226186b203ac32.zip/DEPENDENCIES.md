# Dependencies and rights


These packages are restored by .NET, not copied into RuneSchema's runtime DLLs:

| Package | Version | Upstream license |
| --- | --- | --- |
| [CUE4Parse](https://github.com/FabianFG/CUE4Parse) | 1.2.2.202609 | Apache-2.0 |
| [AssetRipper.TextureDecoder](https://github.com/AssetRipper/TextureDecoder) | 2.6.2 | MIT |
| [SkiaSharp](https://github.com/mono/SkiaSharp) | 2.88.9 | MIT |
| Microsoft.Bcl.Memory | 10.0.10 | MIT |

Their transitive dependencies retain their own notices/licenses; see the NuGet
package metadata and `packages.lock.json`. The tool reads desktop block/raw
texture formats through AssetRipper; it does not use CUE4Parse-Conversion or
ImageSharp's encoding pipeline.

Supply your own matching `.usmap` and licensed local Oodle DLL. Neither is
redistributed by this script. Do not include game PAKs, mappings, decoder DLLs,
player saves or private diagnostic files when distributing the cache tool.
Generated artwork/text retains its original rights; a cache is not a rights grant.
