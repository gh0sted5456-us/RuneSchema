set(DEFAULT_COMPILER_FLAGS "-fms-extensions" PARENT_SCOPE)

set(LINKER_FLAGS "" PARENT_SCOPE)
set(DEFAULT_SHARED_LINKER_FLAGS "${LINKER_FLAGS}" PARENT_SCOPE)
set(DEFAULT_EXE_LINKER_FLAGS "${LINKER_FLAGS}" PARENT_SCOPE)

set(Shipping_FLAGS "" PARENT_SCOPE)

# Compiler-specific definitions
# Currently no GNU-specific definitions needed
# add_compile_definitions(
#     # Add GNU-specific definitions here if needed
# )