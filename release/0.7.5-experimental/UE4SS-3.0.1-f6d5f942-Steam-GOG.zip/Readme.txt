=================================
 INFO
=================================
UE4SS with optional sigs for Dragonwilds

=================================
 INSTALL
=================================
1. STEAM: Go to your Steam Library, find "RuneScape: Dragonwilds", right-click,
   Manage -> Browse Local Files. This is your game root folder.
2. Extract content of the zip-archive inside root folder. If you did everything correctly,
   folder "ue4ss\" will be near "RSDragonwilds-Win64-Shipping.exe"
   in "RSDragonwilds\Binaries\Win64\"
3. Install optional file "UE4SS Signatures" in case any of the mods require FText support
4. Installation is complete.

EXAMPLE:
The game is installed into:
d:\Steam\steamapps\common\RSDragonwilds -- this is your <root_game_folder>
So you download the mod ZIP file, right click on it, select "Extract All"
and choose that <root_game_folder> as a target, exactly, 1:1.
Easy.

=================================
 UNINSTALL
=================================
Delete "dwmapi.dll" and "ue4ss\"
WARNING: Vortex DOES NOT delete it properly!


=================================
 CONFLICTS
=================================
Other modloaders


=================================
 TROUBLESHOOTING
=================================
Before making a bug report make sure to collet a log file in
<game_root>\RSDragonwilds\Binaries\Win64\ue4ss\UE4SS.log
and attach to your report.



=================================
 UE4SS CONFIGURATION
=================================
For performance reasons,
  HookAActorTick
  HookEngineTick
  HookGameViewportClientTick
are disabled.

=================================
 UE4SS CONFIGURATION
=================================
- v0.4 - updated UE4SS
- v0.3 - split signatures and main UE4SS installation
- v0.2 - added ability to choose which sig to use with a simple edit
- v0.1 - updated FText sig for 0.7.13