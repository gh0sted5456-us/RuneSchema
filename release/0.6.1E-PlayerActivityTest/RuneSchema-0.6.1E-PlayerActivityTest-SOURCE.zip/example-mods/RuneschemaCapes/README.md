# RuneSchema Capes — parallel-load proof

This independent mod creates ten new capes from the baked White Adventurer's
Cape. It is included beside `DawnveilPaladinSet` to test multiple mods contributing
runtime clones, wearable rows, and recipes during the same launch.

## Lane separation

- `/assets/baseline-capes.json` contains only `$Clone`, identity, availability,
  display name, and flavour text. It does not author a DataTable handle.
- `$Clone` preserves the baked `DT_WearableEquipment` pointer and changes only
  the copied row name to each clone's exact `InternalName`.
- `/raw/wearable-stats.json` adds ten targeted rows whose keys exactly match those
  internal names. It does not reconstruct or replace the table.
- `/recipes/cape-recipes.json` creates the runtime items through their real
  `/Game/RuneSchema/RuneschemaCapes/Items/...` paths.

## Capes

The collection contains Bulwark, Duelist, Archer, Arcanist, Warden, Stormguard,
Spellward, Vital, Versatile, and Aegis variants. Each has a unique PersistenceID,
InternalName, wearable row, name, description, and defensive profile.

All ten recipes are placed at the Mystic Forge under `Armour/Cape` and consume
three to eight Mystic Cloth.

This build uses deterministic folder order from `runeschema.txt` and sorted JSON
filenames. The separate cape pack remains a substantial clone/raw/recipe
workload beside the Paladin examples so both lanes can be tested together.

Credits: RuneSchema created by Snorkles; extended features by Jonesing4Space.
