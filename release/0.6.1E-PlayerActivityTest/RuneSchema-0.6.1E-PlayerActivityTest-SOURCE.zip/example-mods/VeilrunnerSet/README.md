# Veilrunner equipment — Surge implementation in progress

Four equipment clones and their four recipes are retained. The raw file still
contains only the three custom wearable-stat rows. Armour appearance and Medium
classification are unchanged.

The incorrect Windstep GrantedEffects entry has been removed from the Striders.
Surge is USD_Surge, a utility spell, not a gameplay-effect class. This source
snapshot does NOT grant Surge yet. There is no fake GrantedUtilitySpells property
in the active item JSON, and no persistent unlock is attempted.

Implementation is awaiting the native equipment/spell API export. The probe
button in RuneSchema > Tools writes diagnostics/EquipmentSpellAPI.json. It reads
class/function/struct metadata and resolves the Surge asset, without granting
spells, changing equipment, or writing saves. Native removal ownership and equip
callbacks must be established before activating the feature.

This draft mod is included in source only. The probe update does not install it
or replace any existing item data. Do not treat this as the completed Surge set.

Credits: RuneSchema created by Snorkles; extended features by Jonesing4Space.
