# SimplePaladinProof

This is the smallest useful Paladin armor cloning test.

- `/assets/paladin-body.json` clones the baked Paladin platebody into one genuinely new item.
- The clone retains the original Paladin meshes, icon, equipment slot, armor weight, durability, and other baked defaults.
- Only identity, soft-delete state, display name, and flavour text are authored in `/assets`.
- `$Clone` automatically changes the copied wearable row handle to `rs_simple_paladin_body`.
- `/raw/wearable-row.json` creates only that matching row in the existing `DT_WearableEquipment` and supplies the armor ratings.

There are no recipes, gameplay effects, set bonuses, mesh substitutions, journal entries, or other cloned pieces in this test.
