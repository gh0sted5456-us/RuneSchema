# Ghost visual-effect test

This optional demonstration applies Dragonwilds' cooked ghost overlay to the
first connected player and to Rattleblade Fen. It also proves that a late
`$Patch` can add `VisualEffect` to existing `/players` and `/spawns` definitions.

The supported form is:

```json
"VisualEffect": {
  "Type": "Ghost",
  "MainColor": { "R": 0.22, "G": 0.75, "B": 0.95, "A": 1.0 },
  "SecondaryColor": { "R": 0.05, "G": 0.25, "B": 0.75, "A": 1.0 }
}
```

`Type` currently accepts only `Ghost`. RGB channels accept finite values from
0 through 100 and alpha accepts 0 through 1. Both color objects are optional;
omitting them uses the baked material defaults. The effect changes rendering,
not identity, stats, allegiance, collision, navigation, or loot.

The overlay is applied to compatible mesh components already attached when the
spawn/player rule runs. Equipment attached later may require the rule to run
again (for example, after a native player restart).

Ghost is only a material overlay. RuneSchema does not force visibility, invoke
a montage, replace an enemy's `SpawnActionClass`, or bypass its native spawn
point. Enemy entrance animations and effects therefore remain selected by the
cooked AI data. Meshes are enumerated through the reflected
`K2_GetComponentsByClass` wrapper available in this game build.

Keep this mod below `FourPlayerProfiles` and `NamedSkeletonGroundingTest` in
`runeschema.txt`. Disable it with `GhostVisualEffectsTest : 0`.

Credits: Snorkles and Jonesing4Space.
