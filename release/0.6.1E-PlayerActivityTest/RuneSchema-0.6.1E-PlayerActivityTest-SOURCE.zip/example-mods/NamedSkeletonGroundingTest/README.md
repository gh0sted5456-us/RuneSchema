# Named skeleton grounding control

This diagnostic mod places three ordinary skeleton variants in a row 1,400
Unreal units south of the Zogre test row. It uses confirmed cooked AI and native
spawn-point Blueprint paths from the current spawn implementation.

Each entry exercises `"Z":"$"`, a distinct visible scale, and an instance
display name:

- Rattleblade Fen — one-handed warrior, scale `1.20`
- Marrowcleaver Voss — two-handed marauder, scale `0.85`
- Ashstring Pell — archer, scale `1.35`

They now use native `Roam` behavior with individual `RoamRadius` and
`RoamMaxZTolerance` values. This tests grounded placement first, then the cooked
spawn point's own navigation-aware roaming rather than a RuneSchema polling
movement loop.
If these names appear but the Zogre names do not, Zogre uses a boss-specific UI
path. If neither appears, the generic late health-bar binding still needs the
bounded reconciliation retry.

Each entry also has an authoring-only `Id`. `ZZ_PatchProof` targets
`NamedSkeletonGroundingTest:rattleblade-fen` and expands only that skeleton's
roam and sentry radii after all ordinary spawn definitions are collected.
`GhostVisualEffectsTest` independently adds the baked ghost overlay and two tint
colors to Rattleblade Fen through the same late-patch lane.

`Z:"$"` means a vertical blocking-surface trace, not a navmesh projection.
Use `$+offset` or `$-offset` to move relative to the detected surface.

Credits: Snorkles and Jonesing4Space.

