# Zogre spawn lifecycle test

This expands the supplied Zogre template into three named encounters beside the
named resource-node test. The Zogres form a parallel row 1,400 Unreal units
south of the resources, sharing the nodes' X positions. RuneSchema
recognizes this exact AI class and creates the game's cooked
`BP_SpawnPoint_Zogre` wrapper, so native construction and AI-director
registration run before the character is emitted. All authored portable
`AISpawnPoint` fields remain applied to that instance.

Each Zogre keeps the normal `Zombie_Ogre` loot route and adds one distinct,
guaranteed `/raw` bonus route:

- Grimtooth the Tollkeeper — one Zogre Pack
- Borgruk Iron-Gut — one Goblin Pack
- Mournmaw the Hoarder — one Zombie Pack

The authored scales are deliberately obvious for verification: Grimtooth is
`1.20`, Borgruk is `0.85`, and Mournmaw is `1.35`.

The names are per live instance and are authored in both `DisplayName` (ordinary
enemy lane) and `BossName` (boss UI lane). They must replace `Zogre` in whichever
health-bar presentation the cooked Zogre uses.
Test names, unique bonus drops, initial appearance, combat, death, save/reload, and
the authored four-hours-and-one-minute respawn duration.

All three entries use `"Z":"$"`; RuneSchema performs the native
vertical ground trace at each authored X/Y coordinate and replaces Z with the
blocking surface height before creating the spawn point. `$+25` and `$-25`
apply an offset from that surface.

These test encounters use `"AmbientBehaviour":"EAmbientAIBehaviour::Idle"`
because the supplied resource-node coordinates are outside a usable ambient-AI
roam goal area. `/spawns` still supports per-entry roaming: use
`"AmbientBehaviour":"EAmbientAIBehaviour::Roam"`, plus optional
`RoamRadius`, `RoamMaxZTolerance`, and `RoamGoalQueryType`, when the spawn is
placed on confirmed AI navigation. Forcing `Roam` at the current test location
causes the game to repeatedly report that it cannot compute a valid goal point.
Ground tracing places an actor on a surface; it does not prove that the surface
belongs to the ambient-AI navigation mesh.

Credits: Snorkles and Jonesing4Space.

