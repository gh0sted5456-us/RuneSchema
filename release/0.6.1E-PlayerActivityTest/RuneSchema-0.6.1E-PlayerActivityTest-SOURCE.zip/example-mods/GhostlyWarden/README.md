# Ghostly Warden � optional test mod

Requires 0.6.1E-authoring1. Copy GhostlyWarden to RuneSchema/mods and enable it in your existing load order. Keep the folder name: it forms persistent clone paths. Install the same item/recipe definitions on server and clients. This example is not enabled automatically.

Mystic Forge recipes convert one original piece plus 10 Wild Anima into its Warden counterpart. Head/body/legs retain the source Emberguard base armor types (Steel/Paladin), not Emberguard custom bonuses. The mantle copies the Artisan cape, including its native properties. These are unique item identities and do not change normal armor or the player's body. Exact crafting/UI/rendering remains a live test.

Change $VisualEffect in assets/ghostly-warden.json to tune colors or choose Overlay/BodyMaterial independently. No /equipment behavior or permanent enchantment is added.
