# Bronze Sword with Iron appearance

This is a direct `/assets` edit of the vanilla Bronze Sword. It uses no
`$Clone`, creates no new item, changes no `PersistenceID` or `InternalName`, and
does not touch damage, PowerLevel, durability, recipe, or save identity.

Only three presentation fields are replaced with their exported Iron Sword
values: inventory `Icon`, world/inventory `StaticMesh`, and equipped
`HeldEquipmentActorClass`. Disable this mod to restore the untouched cooked
appearance on the next clean game start.

Credits: RuneSchema created by Snorkles; extended features by Jonesing4Space.
