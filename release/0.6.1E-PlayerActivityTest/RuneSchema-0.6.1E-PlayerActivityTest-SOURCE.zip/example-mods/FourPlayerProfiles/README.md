# Full `/players` authoring guide

The active `players/profiles.json` demonstrates four connection-order roles. The
two `.disabled` files document arbitrary attribute and appearance syntax without
loading placeholder FModel row or attribute names into a real game.

## Selectors

| Field | Type | Meaning |
| --- | --- | --- |
| `PlayerName` | string | One name, `*`, or `*N`. |
| `PlayerNames` | string array | Any listed name/slot selector. |
| `PlayerGuid` | string | One stable character GUID. |
| `PlayerGuids` | string array | Any listed GUID. |

`*` selects everyone. `*1`, `*2`, etc. select stable first-seen connection slots
for the current world session. GUID selectors are authoritative when present;
names alongside GUIDs are descriptive rather than an additional OR match.

An optional authoring-only `Id` gives a rule a deterministic patch identity.
For example, another mod may target `FourPlayerProfiles:first-player-tank` with
`$Patch`/`$Target`. `Id` is removed before the live player rule is registered.

## Complete dedicated field reference

| Field | Range | Effect |
| --- | ---: | --- |
| `Scale` | 0.25–3 | Multiplies original pawn scale. |
| `HealthMultiplier` | 0.1–100 | Multiplies baseline maximum health. |
| `MaxHealth` | 1–1,000,000 | Sets absolute maximum health. |
| `BaseHealth` | 1–1,000,000 | Alias for `MaxHealth`. |
| `DefenseMultiplier` | 0.1–100 | General defense multiplier. |
| `DamageMultiplier` | 0.1–100 | General outgoing damage multiplier. |
| `StaminaMultiplier` | 0.1–100 | Multiplies baseline maximum stamina. |
| `MaxStamina` | 1–1,000,000 | Sets absolute maximum stamina. |
| `WalkSpeedMultiplier` | 0.1–10 | Walking speed multiplier. |
| `RunSpeedMultiplier` | 0.1–10 | Running/sprint speed multiplier. |
| `CarryWeightMultiplier` | 0.1–100 | Multiplies baseline carry capacity. |
| `MaxCarryWeight` | 1–1,000,000 | Sets absolute carry capacity. |
| `PoisonResistanceMultiplier` | 0–100 | Poison-resistance multiplier. |
| `StaminaRecoveryMultiplier` | 0–100 | Stamina regeneration multiplier. |
| `PhysicalAttackMultiplier` | 0–100 | Physical attack multiplier. |
| `MagicalAttackMultiplier` | 0–100 | Magical attack multiplier. |
| `MagicAttackMultiplier` | 0–100 | Alias for `MagicalAttackMultiplier`. |
| `RangedAttackMultiplier` | 0–100 | Ranged attack multiplier. |
| `RangeAttackMultiplier` | 0–100 | Alias for `RangedAttackMultiplier`. |
| `PhysicalDefenseMultiplier` | 0–100 | Physical defense multiplier. |
| `MagicalDefenseMultiplier` | 0–100 | Magical defense multiplier. |
| `MagicDefenseMultiplier` | 0–100 | Alias for `MagicalDefenseMultiplier`. |
| `RangedDefenseMultiplier` | 0–100 | Ranged defense multiplier. |
| `RangeDefenseMultiplier` | 0–100 | Alias for `RangedDefenseMultiplier`. |

Do not combine `HealthMultiplier` with `MaxHealth`/`BaseHealth`,
`StaminaMultiplier` with `MaxStamina`, or `CarryWeightMultiplier` with
`MaxCarryWeight` in the same rule.

## Arbitrary attributes

`AttributeMultipliers` maps an exact FModel/SDK attribute asset or runtime class
name to a multiplier. `Attributes` maps an exact identifier to exactly one `Set`,
`Add`, or `Multiply` operation. See `advanced-attributes.json.disabled` and replace
its placeholders with verified cooked identifiers.

## Appearance

Supported canonical fields are `BodyType`, `FaceType`, `HairPreset`,
`FacialHairPreset`, `SkinTone`, `HairColor`, `EyeColor`, and `EyebrowColor`.
Aliases include `Head`, `HairStyle`, `BeardStyle`, and `SkinColor`. Values may be
vanilla row names or objects containing `Name`, `Row`, or `RowName`, with optional
`DataTable`. Appearance packs can publish `appearance/manifest.json` with `Tables`
and safe `FallbackRows`; selections may name a `Source` plus a fallback.

## Ghost overlay

`VisualEffect` is independent of saved character customization. The currently
supported type is Dragonwilds' baked `Ghost` overlay with optional `MainColor`
and `SecondaryColor` RGBA objects. See `GhostVisualEffectsTest` for a complete
late-patch example. RGB accepts 0–100 and alpha accepts 0–1. It changes rendering
only and can itself be added or recolored by a later `/players` patch.

In multiplayer, gameplay fields are applied only by the authoritative server.
Each client replays `VisualEffect` for local and replicated remote player pawns
when their `PlayerState` arrives. `*1`, `*2`, and later slots use replicated
`PlayerId` order so matching RuneSchema installations resolve the same active
player slot without polling. Named selectors also work for remote visuals. For
a GUID-only visual rule, include the documented player name as a companion
selector when other clients must render it; remote clients do not own that
player's controller and may not expose its character GUID locally.

## Use cases and testing

- Party roles via `*1`–`*4`; server-wide rules via `*`.
- Persistent character profiles via GUID or temporary named-player rules.
- Class-like builds combining movement, carrying, recovery, attack, and defense.
- Total conversions using exact attribute operations and appearance source packs.

Rules apply once when the world becomes ready, then re-apply from captured
baselines only when native `PostLogin` or `ClientRestart` events report a joining
player or replacement pawn. Client visuals additionally use native
`OnRep_PlayerState`. There is no recurring player scan. This preserves `*` and
connection-order selectors (`*1`, `*2`, and so on) without multiplier drift.
Rules follow `runeschema.txt`, then sorted filenames and JSON array order for
deterministic resolution.

Credits: Snorkles and Jonesing4Space.
