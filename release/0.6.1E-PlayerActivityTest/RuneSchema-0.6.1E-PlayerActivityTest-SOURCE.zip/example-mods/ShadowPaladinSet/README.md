# Shadow Paladin Set

This independent mod builds a complete medium-armor Shadow Paladin set: helm,
cuirass, greaves, shadowscale mantle, and Night-Oath Dagger.

- The item is cloned from the baked Paladin helm.
- It uses the male and female Dark Mage hood mesh-data assets and icon.
- `ArmorWeight` is explicitly changed to `EArmorWeight::Medium`.
- Its wearable row is keyed by the exact `rs_shadow_paladin_helm` InternalName.
- It grants the exact native ShadowVeil class exported at
  `/Game/Gameplay/UtilityMagic/PerkSpells/ShadowVeil/GE_ShadowVeil.GE_ShadowVeil_C`.
- `blueprints/ShadowCloak.json` changes the cooked Shadow Veil class duration to
  infinite using the full Blueprint asset path and the class-default `Data`
  property. This also makes the cast spell infinite while the mod is enabled.
  The in-game test must confirm whether attacking has a separate hard-coded
  removal rule; the override eliminates timer expiry but cannot prove that rule
  from exported data alone.
- The Mystic Forge recipe and journal entry point to the clone's real runtime path.

The body and legs remain Paladin clones but use the exported Dark Mage meshes
and icons. The mantle is a Shadowscale Cape clone. The dagger is a Steel Dagger
clone. Every item has a unique cooked gameplay effect:

- helm: -33% ranged-attack stamina cost
- cuirass: +40% stealth movement speed
- greaves: +25% weak-point damage
- mantle: infinite Shadow Veil duration (experimental Blueprint override)
- dagger: +25% damage to wolves

All five items have their own Mystic Forge recipes and journal entries. The
four wearable rows are keyed only by their cloned InternalNames; no full vanilla
`DT_WearableEquipment` snapshot is written.

`BuffDatas` uses plain strings for its title and description, matching the working
RuneSchema demonstration format.

Credits: RuneSchema created by Snorkles; extended features by Jonesing4Space.
