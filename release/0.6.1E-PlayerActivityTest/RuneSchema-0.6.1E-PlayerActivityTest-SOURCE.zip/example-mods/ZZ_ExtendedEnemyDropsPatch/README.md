# Extended Enemy Drops field patch

Requires your existing Extended Enemy Drops mod. Load this after that folder:

Extended Enemy Drops : 1
ZZ_ExtendedEnemyDropsPatch : 1

Patches DT_LootDropTable:Wolf, matching the Monstrous Fang SpawnedItemData
reference in Resources. Sets MinimumDropAmount = 2 and MaximumDropAmount = 3.
It preserves DropChance, flags, all other entries, and every other table row.
The supplied mod appends one matching entry. If another mod or native data also
contains it, the selector reports ambiguity and changes no entries. Add more
matching fields to distinguish duplicates, or inspect the final order and use
$Index. No missing row or missing array entry is created.

Raw patch auto-reload applies to the currently loaded table; a game restart is
required for a clean full-load-order test and for replay after later table loads.
Runtime reflection and observed drops still require in-game verification.
Your original Desktop mod is not modified or copied into this example.
