# Masterwork cape test (optional)

Load after CloneCapeProof and set `ZZ_MasterworkCapeTest : 1` in runeschema.txt.
This patches only the existing CloneCapeProof runtime clone. It does not alter
any original game item. Turn off the test and restart the game to compare.

The two fields come from the Paladin export: bIsMasterworkItem = true and
MasterworkType = EMasterworkUpgradeType::Vestige. The generic asset loader already
supports boolean and named enum properties, so no special item loader is needed.

This changes masterwork classification and can affect masterwork gameplay. It is
not a verified color-only option. Check inventory background, tooltip, equipment
slot, and masterwork UI in game. Basic Item is the type-tag lookup fallback;
this patch intentionally makes no claim about changing that label or every color.
