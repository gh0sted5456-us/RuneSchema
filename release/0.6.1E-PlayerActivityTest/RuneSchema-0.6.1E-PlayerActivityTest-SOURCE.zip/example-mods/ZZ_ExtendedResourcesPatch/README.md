# Extended Resources field patch

Requires your existing Extended Resources mod. Load this after that folder:

Extended Resources : 1
ZZ_ExtendedResourcesPatch : 1

The patch matches the ash-wood reference in BP_FellableTree_Ash_C's
ItemDropOnSplitComponent.ItemsToDrop array, then sets MinToDrop = 3 and
MaxToDrop = 5. It preserves grouping, probability, every other drop entry,
and ItemDropOnDestructionComponent. The supplied source has one matching wood
entry in this array. Runtime field types and final drops need in-game validation.

Use a full canonical ItemDataClass object-path string for $Match. An index can
be used instead, but it depends on the current load-order result. No match or
multiple matches rejects the entire array operation. Restart after editing.
Your original Desktop mod is not modified or copied into this example.
