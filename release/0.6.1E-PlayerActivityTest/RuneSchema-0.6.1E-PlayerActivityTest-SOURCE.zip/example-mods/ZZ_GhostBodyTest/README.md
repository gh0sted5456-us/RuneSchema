# Ghost body and overlay test (optional)

Enable `ZZ_GhostBodyTest : 1` after GhostVisualEffectsTest, FourPlayerProfiles and
NamedSkeletonGroundingTest. This adds `BodyMaterial: true` to the first-player
and Rattleblade Fen ghost definitions, retaining their existing tint values.

The default is false, preserving overlay-only behavior. True creates a dynamic
MI_Ghost body material and applies it to all existing slots on compatible meshes.
MainColor maps to Color A; SecondaryColor maps to Color B. The separate overlay
retains MainColor_Top and SecondaryColor_Top. Omitted colors use baked defaults.

These paths and parameters match the Cathan exports supplied in FINDINGS_ghost.
Appearance still needs an in-game check for creatures and players. FadeControl
uses custom primitive data; this feature does not attempt to tune it. The effect
applies to meshes available when the rule runs, including equipment meshes.
Later equipment changes are not continuously rescanned. Disabling/changing the
rule does not restore original body slots on an already affected actor: disable
this test and restart the game for a clean comparison. Body replacement does not
change spawn entrances, identity, combat values, allegiance, or loot.
