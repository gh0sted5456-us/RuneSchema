# Ghost ash trees

Enable `GhostAshTrees : 1` and restart. No dependency on the Extended drop mods.
The example adds ghost overlay rendering to every initialized actor of:
- BP_Tree_Ash_01_C (standing ash; verified stable spawn example)
- BP_FellableTree_Ash_C (the class in Extended Resources/MM_Trees_Ash.json)

It preserves drop settings. Set BodyMaterial to true to also test ghost body-slot replacement on trees.
The effect uses the existing actor PostInitializeComponents hook and shared
material instances per effect signature, without a polling loop or extra detour.
Materials use the game instance as context, rather than retaining the first tree.

This is exact-class matching. Other ash blueprint classes, foliage instances,
stumps or split logs require their own verified class rules. Existing actors are
not rescanned after editing the file. Restart to apply or remove the effect.
The example does not change collision, entrances, drops or resource identity.
Appearance, mesh coverage, felling, streaming and multiplayer need in-game checks.

