# Dawnveil Paladin Set

An eight-item RuneSchema test mod that combines Paladin plate, a Shadowscale hood,
and two Saradominist cloak variants. It requires RuneSchema 0.6.1E and does not require a DLL
rebuild.

## What is cloned

| New item | Clone base | Equipped appearance |
| --- | --- | --- |
| Dawnveil Paladin Hood | Paladin's Helm | Male and female Shadowscale Hood mesh-data assets |
| Dawnveil Paladin Plate | Paladin's Platebody | Original Paladin body meshes |
| Dawnveil Paladin Greaves | Paladin Platelegs | Original Paladin leg meshes |
| Dawnveil Oathcloak | Ava's Accumulator | Saradominist cloak meshes and icon |
| Dawnveil Windcloak | Ava's Accumulator | Saradominist cloak meshes and icon |
| Dawnveil Oathsword | Steel Sword | Original steel sword actor, icon, and mesh |
| Dawnveil Aegis | Steel Shield | Original steel shield actor, icon, and mesh |
| Dawnveil Luminary Staff | Blightwood Battlestaff | Original battlestaff actor, icon, and mesh |

Every item has a new permanent `PersistenceID`, `InternalName`, runtime object path,
display name, flavor text, Power Level 10, and durability. The five wearables use
private stat rows; the three weapons use their native direct combat fields. No
vanilla item or shared row is changed.

Each wearable row is keyed by the item's exact `InternalName`. The `/assets` file
does not author or reconstruct `WearableEquipmentDataTableRowHandle`; `$Clone`
retains the baked table pointer and binds the copied handle to that row automatically.

## Ratings

| Piece | Defense | Melee | Ranged | Magic | Vital Shield |
| --- | ---: | ---: | ---: | ---: | ---: |
| Hood | 18 | 3 | 0 | 3 | 5 |
| Plate | 42 | 6 | -1 | 4 | 10 |
| Greaves | 26 | 4 | 0 | 3 | 5 |
| Oathcloak | 8 | 2 | 2 | 5 | 10 |
| Windcloak | 6 | 0 | 2 | 4 | 0 |
| Full set | 94 | 15 | 1 | 15 | 30 |

## Gameplay effect experiment

The oathcloak's `GrantedEffects` array references the native infinite equipment
effect `GE_HeavyArmorSetT1ReduceBlockStaminaCost_C`. The exported effect modifies
`BlockStaminaCostModifierAttribute` by `-0.33`; the inventory-facing `BuffDatas`
entry describes that as 33% lower block stamina cost and uses the Amulet of Defense
icon rather than an empty texture reference.

The Luminary Staff uses a direct `DamageMultiplier` of `4.6125`, exactly 12.5%
above the Blightwood Battlestaff's exported `4.1`. Its `BuffDatas` entry presents
that difference and uses the Amulet of Magic icon. It does not attach a second
GameplayEffect, keeping the damage test attributable to one native item field.

The Dawnveil greaves grant the native Windstep effect using the exact object path
demonstrated by the supplied `AddWindstepToLegs` example. This is kept separate
from `BuffDatas`: the GameplayEffect supplies behavior, while no speculative
Windstep tooltip structure is authored.

This deliberately grants the existing effect directly while the cloak is equipped;
it does not create or patch a GameplayEffect class. Test the stamina cost before
equipping, with only the cloak equipped, and after unequipping. Also watch for
stacking if another system independently grants the same heavy-armour-set effect.

The Windcloak instead grants the native light-armor stamina-regeneration-delay
effect. Both cape variants use the plain-string `BuffDatas` title and description
shape demonstrated by the working supplied mods.

## Crafting

The armor, sword, and shield use the Armour Bench; the staff uses the Mystic Forge.
Every recipe follows the demonstrated placement contract, for example:

```json
{"Table":"DT_CraftingStationsDataTable","Row":"ArmourBench","Category":"Dawnveil Paladin Set"}
```

Recipes use Iron Bars, Hard Leather, Padded Cloth, Blightwood, Wild Anima, and Vault
Shards. They award the native Tier 4 forge XP event and create the clones through
their real `/Game/RuneSchema/DawnveilPaladinSet/Items/...` runtime object paths.

## Journal

Five entries cover the oathplate, hood, two cloaks, and staff. Their `ItemData`
references use the same real runtime paths as the recipes. The entries are manually
unlocked and placed in the Ghornfell armor-recipe journal section.

## Test order

1. Install this as the only RuneSchema demonstration mod for the test.
2. Confirm seven recipes appear at the Armour Bench and the staff at the Mystic Forge.
3. Craft and equip each piece, checking names, icons, meshes, ratings, and weapon fields.
4. Confirm the hood uses the Shadowscale skin on male and female characters.
5. Confirm the oathcloak uses the Saradominist appearance, shows its defense icon,
   and reduces block stamina use while equipped.
6. Confirm the staff shows its magic icon and compare spell damage with the ordinary
   Blightwood Battlestaff.
7. Confirm the five journal entries appear, then unequip everything, save, reload,
   and verify all eight items retain their identities.

Credits: RuneSchema created by Snorkles; extended features by Jonesing4Space.
