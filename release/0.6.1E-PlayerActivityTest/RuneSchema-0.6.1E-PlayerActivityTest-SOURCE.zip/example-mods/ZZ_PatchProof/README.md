# ZZ_PatchProof

This diagnostic mod demonstrates deterministic late patching. Keep it below
`DawnveilPaladinSet` in `runeschema.txt`.

- `/assets` changes only `Name`, `FlavourText`, and `BaseDurability` on an
  existing cloned item. Identity fields are protected.
- `/raw` targets one existing DataTable row with `DT_Name:RowName`; a missing
  row is an error and is never created by `$Patch`.
- `/recipes` changes one nested recipe property.
- `/journal` changes one journal-entry field.
- `/players` patches the first connected player's identified profile without
  changing its `*1` selector.
- `/spawns` patches Rattleblade Fen's roam/sentry radii before the spawn point
  is registered.

Every patch uses this envelope:

```json
{
  "AnyDiagnosticLabel": {
    "$Patch": "EarlierMod:Identity",
    "$Target": {
      "OnlyTheFieldsToChange": true
    }
  }
}
```

For `/raw`, the patch envelope is the document root and the identity is
`DataTable:RowName`. Patches never create missing targets. Objects merge
recursively; keyed recipe arrays merge by stable item identity; unkeyed arrays
are replaced as a unit.

For `/players` and `/spawns`, give the original entry a unique `Id`, then target
it as `OwnerMod:Id`. `Id`, entry type, and player selector fields are protected
identity and cannot be changed by `$Target`.
