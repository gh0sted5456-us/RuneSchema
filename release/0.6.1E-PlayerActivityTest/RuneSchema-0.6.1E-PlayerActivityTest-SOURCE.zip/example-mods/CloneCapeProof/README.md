# CloneCapeProof

This is a deliberately minimal two-lane proof.

- `/assets/clone-cape.json` clones one baked `ItemData` and assigns a unique item identity. No DataTable fields are authored there.
- `$Clone` automatically preserves the baked wearable's DataTable pointer and changes only its row name to the new `InternalName`.
- `/raw/wearable-row.json` adds only the single `rs_clone_cape_proof` row to the existing live `DT_WearableEquipment` table.

The raw file does not export, replace, or reconstruct the DataTable. Its shape matches the working Capes mod: table name, row name, and only the stats that need values.

No recipe, journal, spawn, player, gameplay-effect, or patch feature is part of this proof. Spawn or inspect the item by `rs_clone_cape_proof` after the loader reports successful identity registration.
