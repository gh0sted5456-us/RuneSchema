# Expanded `/spawns` authoring guide

The included `AISpawnPoint` creates a native spectral zombie named
`The White-Road Revenant` without changing the shared AI class default.

## Shared fields

| Field | Meaning |
| --- | --- |
| `Type` | Required: `AISpawnPoint`, `Actor`, or `RemoveActor`. |
| `Location` | Required `{X,Y,Z}` world position. |
| `Rotation` | Optional `{Pitch,Yaw,Roll}`. |
| `Scale` | Positive number or `{X,Y,Z}`. |
| `DisplayName` | 1–128 character per-instance AI name. |
| `LootRow` | A `DT_EnemyLootDropTable` row selected for this AI instance. |
| `DropIncreasePercent` | Nonnegative opt-in drop-row percentage. |
| `HealthMultiplier` | 0.1–100; scales initialized maximum/current health. |
| `DamageMultiplier` | 0.1–100; scales supported combat component multipliers. |

## `AISpawnPoint`

`AIClass` is required. `PowerLevel` is the native spawn-point level field. Other
convenience fields are `Mandatory`, `Respawn`, `RespawnDuration`,
`AmbientBehaviour`, `DespawnBehaviour`, `RequiresActivation`,
`IgnoreNavmeshRequirement`, `RoamRadius`, `RoamMaxZTolerance`,
`RoamGoalQueryType`, `SentryRadius`, `HearingRange`, `HearingZRange`,
`IdleAnimTag`, `Tags`, `MinSpawnDistance`, `MaxSpawnDistance`, `Variants`, and
advanced `Properties`.

Three reflected-property scopes expose exact cooked FModel fields:

- `Properties`: fields on the `AISpawnPoint`.
- `CharacterProperties`: fields on the spawned AI character.
- `ComponentProperties`: component name to exact fields on that component.

Use those scopes for verified curve, health, attack, attribute, and component
fields. Missing fields/components are logged. Prefer `HealthMultiplier` and
`DamageMultiplier` for ordinary combat scaling.

## Other types and loot

`Actor` requires a unique `Id` and full `Class`, and supports transforms plus
advanced `Properties`. `RemoveActor` requires a `Class` and accepts a narrow
positive `Radius` around `Location`.

For a named character with extra loot, author matching `/raw` rows in
`DT_LootDropTable` and `DT_EnemyLootDropTable`, then select that route with
`LootRow`. The sample keeps a guaranteed native zombie pack and adds a 35% chance
for one or two Goblin Packs. `DropIncreasePercent` remains disabled unless
`enableExperimentalDropScaling` is explicitly enabled in RuneSchema settings.

Replace the demonstration coordinates with a safe location before serious play.
Test streaming, respawn, overhead-name refresh, duplicate prevention, navigation,
and save reload.

Credits: Snorkles and Jonesing4Space.
