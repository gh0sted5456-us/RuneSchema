# Named resource-node instance test

This mod places three ordinary vanilla resource actors at the exact supplied
coordinates near Death's Shop:

| Node | Display name | Coordinates |
| --- | --- | --- |
| Ash tree | `Wayfarer's Ash` | `15806, 185344, -3290` |
| Stone | `Dragonstone Boulder` | `16206, 185344, -3350` |
| Medium iron | `Ironheart Vein` | `16606, 185344, -3300` |

Each resource also demonstrates `VisualEffect.Type: "Ghost"`: green for the
ash, blue for iron, and violet for stone. RuneSchema discovers every attached
mesh component, so a resource does not need to expose a specifically named
`StaticMeshComponent` property. The effect is visual only and does not alter
the resource identity, collision, damage, drops, or replenish behavior.

Each entry keeps its original generated class. RuneSchema writes `DisplayName`
only on the managed actor instance after finding it by its stable `SpudGuid`.
It does not clone or patch the Blueprint, edit the class default, or replace the
resource identity.

`UseNativeRespawn: true` records that RuneSchema has placed each source once.
If that stable source is absent on a later game load, RuneSchema treats it as
depleted and does not recreate it. The resource's own native respawn component
and save state remain responsible for the replenish deadline. Omit this field,
or set it to `false`, for ordinary actors that RuneSchema should recreate when
missing.

The test also uses `ComponentProperties` to append one guaranteed bonus drop to
the live instance's existing array: Bird Nest for the ash, Wild Anima for the
stone, and Jade for the iron. The object form `"ItemsToDrop":{"Items":[...]}`
means append; a plain array would replace the existing list. If a resource class
does not expose that exact component, RuneSchema logs the miss and preserves its
normal drops.

If a cooked class does not expose the expected instance `DisplayName` property,
RuneSchema logs a warning and leaves the actor unchanged.

Verify placement, visible interaction name, damage, drops, depletion, respawn,
streaming away and back, save reload, and restoration of the ghost overlay on
native-respawn instances.

Credits: Snorkles and Jonesing4Space.
