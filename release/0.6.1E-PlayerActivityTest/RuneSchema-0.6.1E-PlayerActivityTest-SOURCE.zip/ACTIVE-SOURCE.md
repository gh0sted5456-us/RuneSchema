# Active source

RuneSchema 0.6.1E CHARPREVIEW5 test candidate uses this directory. The clean build is `work/server-equipment-charpreview5-build`, and preserved evidence is under `outputs/menu-ghost-preview5`.

This candidate retains the client/server StackFix-dependent runtime and adds frontend equipment visual reconciliation. A filtered BeginPlay callback stores the exact frontend preview actor after construction and reads `HeadEquipment`, `BodyEquipment`, `LegsEquipment`, and `CapeEquipment` through their `ItemData` references. The `SetOutfit` callback reuses that weak actor reference when an outfit is assigned afterward. Preview overlays are assigned through Unreal's `MeshComponent.SetOverlayMaterial` function so the already-rendering frontend component refreshes its render state. One exact lookup still covers late rule registration. Dedicated servers skip the preview lifecycle.

Normal spawn logging is consolidated into one result line with new, altered, error, AI, boss, resource-node, other-actor, and removal counts. Equipment behaviors use one summary for Shadowveil and Surge. Native binding totals and successful per-entry creation, binding, naming, grounding, loot-row, native-cooked-class, and Ghost-material messages require Advanced verbose logging. Warnings and errors remain visible.

The cached build helper derives its paired reference source directory from the `-build` suffix and applies the same deterministic path remapping and neutral PDB name as the CMake route. Every candidate still requires a fresh dependency and runtime rebuild.

Live verification remains pending for main-menu rendering, world entry, equipment changes, client/server behavior, and normal exit. Do not mark this candidate stable from compilation alone.
