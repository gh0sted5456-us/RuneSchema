# RuneSchema maintenance

- Read ACTIVE-SOURCE.md and docs/CHANGELOG.md before editing; preserve tested source and binary archives.
- Keep each loader responsible for its intended domain. Native equipment effect grants, item properties and perk icons belong in /assets. /equipment handles only validated equipment runtime behavior that data edits cannot express; it must not duplicate asset patching or effect granting.
- For every implementation pass, inspect touched code and its callers for obsolete helpers, redundant state, stale documentation and overlapping loader responsibilities. Remove confirmed unused code; preserve active compatibility behavior. Record what was removed and what validation ran.
- Keep explicit shipping size optimization in both CMake and the cached MSVC build. Check DLL size and compatible UE4SS imports after a build.
- Every RuneSchema version requires a full clean rebuild. Record source/dependency hashes, compiler configuration, log, map and PDB; identify cached dependencies explicitly. Never package incremental release objects.
- Avoid additional polling, startup scans, runtime dependencies or loaders when existing lifecycle events and handlers suffice. Diagnostics stay manually activated.
- Do not reintroduce the withdrawn permanent weapon-enchantment implementation.
- A successful build is a test candidate until the user confirms gameplay. Do not claim a heap-crash fix from compilation or a few successful launches.

- Startup is frozen at the fixed-startup baseline. Do not introduce configurable engine stages, loader reordering, startup delays or alternate boot dispatch during unrelated feature work. Keep future changes isolated from initialization unless the user explicitly requests otherwise.

- Keep only concise comments explaining non-obvious ownership, ABI, ordering or data constraints. Put longer rationale in docs/IMPLEMENTATION.md and version history in docs/CHANGELOG.md. Do not narrate implementation steps or assert safety without evidence. Preserve legal notices, attribution and actionable diagnostics.
