# RuneSchema 0.7.0

RuneSchema is a UE4SS runtime for self-contained RuneScape: Dragonwilds
content mods. It loads validated JSON/JSONC definitions, connects them to
mounted cooked assets, and provides multiplayer presentation and authority
bridges without replacing vanilla game systems.

Run `Build RuneSchema.bat` from this source package to build the main and
plugin DLLs. The installable runtime is published separately.

Based on the original RuneSchema 0.6.0 from Snorkles. This version is
maintained by members of the RSDW Modding Community. PalSchema foundation by
Okaetsu.
